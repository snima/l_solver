#!/bin/bash
module load cuda/5.5
make
